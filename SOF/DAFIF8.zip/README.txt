*** DAFIF Ed 8.0 ***		
*** Version 4.1  ***

*** NOTICE: As of the 1906 AIRAC, the GPS Almanac file will be resetting the week number. 1905 will be 1023, 1906 will be 0002. This is due to the 8 bit limitation put in place back in 1999.

*** NOTICE: NGA is undergoing an AIP scrub to add waypoints that were not previously in DAFIF. The user may see an increase in waypoint data. 

*** NOTICE: There are OCONUS procedures populated in DAFIF where the altitudes along the Final Approach Course may differ from the FLIP depiction, which only depicts MOCAs.  DAFIF may contain higher altitudes to facilitate the HOST designed and sourced constant descent angle.  An agenda item has been forwarded to the FDAWG to address the FLIP depiction."								
		
*** NOTICE: Several APPC tables do not reflect current range of allowable values - refer to the DAFIF specification data dictionary for correct values. Incorrect files include: BDRY_TYPE, ILS_COMP_TYPE, NAV_TYPE, TRM_TRACK_CD, TRM_TYPE, TRM_WPT_DESC_1, TRM_WPT_DESC_3, TRM_WPT_DESC_4.							
						
*** NOTICE: Please submit Quality Feedback for the DAFIF product to the Aero Help Desk at 1-877-817-9134 or AeroHelp@nga.mil (NIPRnet), AeroHelp@nga.smil.mil (SIPRNET), AeroHelp@nga.ic.gov (JWICS).  Our Aero Help desk is staffed Monday - Friday,  0700-1700 CST (1300Z-2300Z), not including holidays.  During non-duty hours, the 877 number will forward to the NGA Operations Center.  Please inform the Ops Center if your issue is mission critical so they can contact our on-call Aeronautical Navigation Office personnel for immediate assistance.		
		
*** NOTICE: The Aeronautical Content Exploitation System (ACES) is available at https://aerodata.nga.mil/AeroBrowser/ 	
		
		
		
NGA 		
DIGITAL AERONAUTICAL FLIGHT INFORMATION FILE:		
		
Directory Organization: 		
	The DVD (DAFIF Edition 8 and MI/AVDAFIF) is a DVD -R, Capacity: 4.7GB, 1 layer, 1 side, Read only, Joliet format. At the highest level, there are 5 directories and 3 files. The directories are: AVDAFIF, DAFIF8, DOCS, MIDAFIF, and QFEEDBAC. They all contain subdirectories. The three files are the ALMANAC.GPS, CPYRIGHT and this ReadMe.txt file. There is a sixty four character limit to the file names and the naming convention has been applied to allow symmetry.
		
1.  AVDAFIF Directory:		
	This directory points to the data files which were structured to facilitate the use of the DAFIF data to run on commercial GIS software applications. Please reference the AVReadme.txt file, within the AVDAFIF directory, for a detailed layout of the data sets.
		
		
2.  DAFIF8 Directory: (Sub-directories: DAFIFT, STATS, and T_TRANS; Files: VERSION and WMM.dat).		
		
-DAFIFT sub-directory (This directory contains 22 folders of tab delimited DAFIF data):		
	APPC  - Appendix C (Tables from the specifications Appendix C)
	ARF   - Air Refueling Routes 	
	ARPT  - Airport Info (Runway, Communications, ILS Components, etc)
	ATS   - Air Traffic Services Routes 	
	BDRY  - Airspace Boundaries (Control zones, Identification zones, etc.)
	HLPT  - Heliport Info (Pad/Runway, Communications, Heliport Navaids)
	HOLD  - Holding Patterns	
	IR    - ICAO Regions (The IR layout for DAFIFT is the same as Boundaries. The outlines of the ICAO Regions are general and based on the ICAO region code Boundary Idents currently found in DAFIF. This is a basic outline ONLY, and will NOT exactly match the official ICAO Region diagram. Data: We used the ICAO code FH as the default until configuration management can provide a new unique ICAO, i.e. IR. Bdry_ident: FH0xxxx, Type as 1 default, Name: ICAO Region (Official region letter as based on ICAO Region diagram) i.e. ICAO REGION A, Con_Auth: NGA, Loc_Datum: Unknown ""U"", WGS_Datum: WGE. Shape: General ""G"", Coordinates: All coordinates are general; we DID NOT follow country boundaries in detail. We did a general match of FIRs, UIRs, etc.)."	
	MTR   - Military Training Routes 	
	NAV   - Air Navigational Aids 	
	ORTCA - Off Route Terrain Clearance Altitude	
	PAPP  - RNAV Precision Approach Path Points	
	PJA   - Parachute Jump Areas	
	PR    - Preferred Routes	
	SUAS  - Special Use Airspace (Dangerous, restricted areas) 
	SUPP  - Airport Supplemental data (fuel oil, remarks, services, etc)	
	SUPPH - Heliport Supplemental data (fuel oil, remarks, services, etc)
	TRM   - Terminal Instrument Procedures (airport SIDs, STARs & IAPs)	
	TRMH  - Terminal Instrument Procedures (heliport SIDs, STARs & IAPs)	
	TZ    - Time Zones (No longer supported in DAFIF effective cycle 1204; the folder will remain for systems that read the existing folder structure)	
	VFR   - Visual Flight Rules (Arrival/Departure Routes for Korea/Germany)	
	WPT   - Waypoints	
		
-STATS sub-directory: 		
	CRCDAFIFT.TXT (We used the standard CRC-32 algorithm standards. Based on the following Little-Endian polynomial: X^32+X^26+X^23+X^22+X^16+X^12+X^11+X^10+X^8+X^7+X^5+X^4+X^2+X+1)	
	DAFIFT.STA files contain transaction totals for the DAFIFT files. (Tab delimited CRC (DAFIFT/TTRANS) - Line feed (Decimal 10 and Hexadecimal 0A) and/or carriage return (Decimal 13 and Hexadecimal 0D) are NOT included in the calculation. The tab files are variable length records written to a text file).	
		
-T_TRANS sub-directory:		
This directory contains 20 folders (There are no transactions for IR or TZ).		
		
-VERSION file: 		
	This is a small, standard ASCII text file that indicates the version of the data set contained on the DVD.
		
	Version file: Edition 8 	
	Version is a 28 character numerical string. 	
	EXAMPLE DAFIF 8.0:	
	1.10E+27	
		
	A. ddmmyyyy �Revision includes Spanish Airspace Updates�	
	Position 1-4 - Production Cycle - i.e. 1103	
	Position 5-12 - Effective Date - DDMMYYYY	
	Position 13-20 - Expiration Date - DDMMYYYY	
	Position 21-22 - Specification Edition - i.e. 08	
	Position 23-28 - Specification Date - MMYYYY	
		
	OUT OF CYCLE UPDATE FORMAT - DAFIF 8.0 and 8.1	
	"Position 1 Mid Cycle Update Version, i.e., A, B, C, etc."	
	"Position 2-3 "". "" A Period and a Space"	
	Position 4-11 Release Date - The Date the Revised Data Becomes Effective	
	Position 12 Blank	
	Position 13-N Description of Release	
		
-WMM.DAT file:		
Requests for the magnetic model, data, charts or other magnetic information should be addressed to:
		
	National geophysical Data Center	
	World Data Center - A (Geomagnetism)	
	NOAA EGC 1	
	325 Broadway	
	Boulder CO 80303	
	(303)497-6478   Fax(303)497-6513 	
	http://www.ngdc.noaa.gov/geomag/WMM/DoDWMM.shtml	
		
		
3.  DOCS Directory: 		
		
		
- Type 1 LOA (As of April 2004, DAFIF has a type I, CNSATM (DO-200A) certification for level 2 (essential) data.  Type 1 LOA CNS/ATM audits are currently administered by the FAA)	
		
- DAFIF Configuration Management Report (report that includes all changes/modifications to the DAFIF specification and/or DAFIF output)		
		
		
4. MIDAFIF Directory:		
	This directory points to the data files which were structured to facilitate the use of the DAFIF data to run on commercial GIS software applications. Please reference the MIReadme.txt files, within the MIDAFIF directories, for a detailed layout of the data sets.	
		
5. QFEEDBAC Directory: 		
	This directory contains two softcopy Quality Feedback Forms (.rtf/.txt format) for forwarding quality issues/comments to NGA. Email issues to quality@nga.mil for resolution.	
	"Customers can also submit Quality Feedback for the DAFIF product to the Aero Help Desk at 1-877-817-9134 or AeroHelp@nga.mil (NIPRnet), AeroHelp@nga.smil.mil (SIPRNET), AeroHelp@nga.ic.gov (JWICS).  Our Aero Help desk is staffed by Aeronautical analysts Monday - Friday,  0400-2030 CST (1000Z-0230Z), including holidays.  During non-duty hours, the 877 number will be automatically forwarded to the NGA Operations Center.  Please inform the Ops Center if your issue is a crisis or an emergency so they can contact our on-call Aeronautical Navigation Office personnel for immediate assistance."	
		
6. ALMANAC.GPS File (This file consists of orbit parameters for each GPS vehicle, on a weekly epoch - YUMA format, transfer protocol: ASCII only, no control codes):		
	The GPS almanac is retrieved from the United States Coast Guard Navigation Center website located here: http://www.navcen.uscg.gov/?pageName=gpsAlmanacs	
	The ASCII text file consists of 15 lines for each vehicle, first line descriptive header, 13 lines of values ending with a blank line, and is self-explanatory. This is NOT a NGA product and is provided for information only.	
	The GPS almanac is retrieved approximately three weeks before the AIRAC effective date. The GPS data is updated weekly so users of this data should evaluate and understand the consequences of using outdated data.	
		
7. CPYRIGHT File: 		
	This text file contains pertinent information regarding Copyright, release, distribution, handling, and storage of the DAFIF data.	
		
8. ReadMe.txt File: 		
	This is the file you are now reading. It is a standard ASCII text file which can be accessed and printed by most text editors or word processors.There were a series of underscores added to the following file in the DOCS file It should not affect anything:DAFIF Terminal Procedure Exclusion Rules, FAA Type 1 LOA 8.0-8.1,Digital Terminals Coding Supplement v4, 8.0 Linked Database Readme.    	

9. DAFIF Release Statement:
	This file is inform the user of current LOA Status, and data deviations and/or alterations that do not meet the DAFIF specification. 	

